const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
// 导入控制器
const memberController = require('../controllers/memberController');
const memberControllerSupabase = require('../controllers/memberController_supabase');
const memberControllerSupabaseProfile = require('../controllers/memberController_supabase_profile');
const { authenticateToken, authorizeAdmin, authorizeMember } = require('../middleware/auth');

// 添加导出会员数据路由
router.get('/export/excel', authenticateToken, authorizeAdmin, memberController.exportMembersToExcel);

console.log('注册会员相关路由');

// 创建会员信息（普通会员）
router.post('/profile', authenticateToken, [
  body('full_name').notEmpty().withMessage('真实姓名不能为空'),
  body('phone').notEmpty().withMessage('联系电话不能为空')
], memberControllerSupabaseProfile.createMemberProfile);

// 获取当前会员信息
router.get('/profile', authenticateToken, memberControllerSupabaseProfile.getMyProfile);

// 更新当前会员信息
router.put('/profile', authenticateToken, [
  body('full_name').optional().notEmpty().withMessage('真实姓名不能为空')
], memberControllerSupabaseProfile.updateMyProfile);

// 管理员获取所有会员列表
router.get('/all', authenticateToken, authorizeAdmin, [
  // 添加分页参数验证
  body('page').optional().isInt({ min: 1 }).withMessage('页码必须大于0'),
  body('limit').optional().isInt({ min: 1, max: 100 }).withMessage('每页数量必须在1-100之间')
], memberControllerSupabaseProfile.getAllMembers);

// 获取会员消息列表
router.get('/messages', authenticateToken, authorizeMember, memberControllerSupabase.getMemberMessages);

// 获取特定消息详情
router.get('/messages/:message_id', authenticateToken, authorizeMember, memberControllerSupabase.getMessageById);

// 获取未读消息数量
router.get('/messages/unread/count', authenticateToken, authorizeMember, memberControllerSupabase.getUnreadMessagesCount);

// 会员发送消息给管理员
router.post('/message-to-admin', authenticateToken, authorizeMember, [
  body('subject').notEmpty().withMessage('消息主题不能为空'),
  body('content').notEmpty().withMessage('消息内容不能为空')
], (req, res, next) => {
  // 使用应用程序的upload中间件
  const upload = req.app.upload;
  upload.single('file')(req, res, (err) => {
    if (err) {
      return res.status(400).json({ message: '文件上传失败', error: err.message });
    }
    next();
  });
}, memberControllerSupabase.sendMessageToAdmin);



// 管理员获取特定会员信息
router.get('/:member_id', authenticateToken, authorizeAdmin, memberControllerSupabaseProfile.getMemberById);

// 管理员更新会员信息
router.put('/:member_id', authenticateToken, authorizeAdmin, [
  body('full_name').optional().notEmpty().withMessage('真实姓名不能为空'),
  body('membership_status').optional().isIn(['正常', '欠费', '冻结', '退会']).withMessage('无效的会籍状态'),
  body('membership_level').optional().custom((value) => {
    // 允许null、空字符串或有效的ENUM值
    if (value === null || value === '' || ['理事', '秘书长', '副理事长', '理事长'].includes(value)) {
      return true;
    }
    throw new Error('无效的会员等级');
  }).withMessage('无效的会员等级')
], memberControllerSupabaseProfile.updateMemberById);

// 管理员删除会员
router.delete('/:member_id', authenticateToken, authorizeAdmin, memberControllerSupabaseProfile.deleteMemberById);

// 管理员发送消息给会员
router.post('/:member_id/message', authenticateToken, authorizeAdmin, [
  body('subject').notEmpty().withMessage('消息主题不能为空'),
  body('content').notEmpty().withMessage('消息内容不能为空')
], (req, res, next) => {
  // 使用应用程序的upload中间件
  const upload = req.app.upload;
  upload.single('file')(req, res, (err) => {
    if (err) {
      return res.status(400).json({ message: '文件上传失败', error: err.message });
    }
    next();
  });
}, memberControllerSupabase.sendMemberMessage);

// 管理员获取消息列表
router.get('/admin/messages', authenticateToken, authorizeAdmin, memberControllerSupabase.getAdminMessages);

// 管理员获取消息详情
router.get('/admin/messages/:message_id', authenticateToken, authorizeAdmin, memberControllerSupabase.getAdminMessageById);

// 管理员标记消息已读
router.put('/admin/messages/:message_id/read', authenticateToken, authorizeAdmin, memberControllerSupabase.markMessageAsRead);

// 添加路由错误处理中间件
router.use((err, req, res, next) => {
  console.error('会员路由错误:', err);
  res.status(err.status || 500).json({
    message: err.message || '服务器内部错误',
    error: process.env.NODE_ENV === 'development' ? err : undefined
  });
});

module.exports = router;